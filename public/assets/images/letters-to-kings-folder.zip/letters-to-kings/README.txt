Letters to Kings image package

letters-to-kings/
    hero.jpg
    poster.jpg
    gallery/
        g1.jpg
        g2.jpg
        g3.jpg

The uploaded ZIP contained 3 actual event photographs.
All were converted to JPG and renamed in source order.
